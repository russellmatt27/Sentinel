""" SAP BTP Audit Log Data Collector v1.0.1"""
import logging
import os
from datetime import datetime, timedelta
import json
import httpx
import azure.functions as func
from azure.identity import ManagedIdentityCredential
from azure.monitor.ingestion import LogsIngestionClient
from azure.storage.blob import ContainerClient
from azure.core.exceptions import ResourceNotFoundError, HttpResponseError

LAST_UPDATE_CONTAINER = "lastupdate"
LAST_UPDATE_FILENAME = "lastupdate.json"
AZURE_WEB_JOBS_STORAGE = os.environ["AzureWebJobsStorage"]
DCR_IMMUTABLE_ID = os.environ["DCR_IMMUTABLE_ID"]
DCR_STREAM_NAME = os.environ["DCR_STREAM_NAME"]
DCR_DCE_URL = os.environ["DCR_DCE_URL"]
BTP_UAA_URL = os.environ["BTP_UAA_URL"]
BTP_CLIENT_ID = os.environ["BTP_CLIENT_ID"]
BTP_CLIENT_KEY = os.environ["BTP_CLIENT_KEY"]
BTP_API_HOST = os.environ["BTP_API_HOST"]
BTP_API_TIMEOUT_SECONDS = int(os.environ["BTP_API_TIMEOUT_SECONDS"])
FUNCTION_SHUTDOWN_TIMEOUT_MINS = int(os.environ["FUNCTION_SHUTDOWN_TIMEOUT_MINS"])
TIMER_SCHEDULE_MINS = os.environ["TIMER_SCHEDULE_MINS"]
MAX_LOOKBACK_DURATION_HOURS = int(os.environ["MAX_LOOKBACK_DURATION_HOURS"])
QUERY_WINDOW_OFFSET_MINS = int(os.environ["QUERY_WINDOW_OFFSET_MINS"])

azure_http_logger = logging.getLogger(
    "azure.core.pipeline.policies.http_logging_policy"
)
azure_http_logger.setLevel(logging.WARNING)

app = func.FunctionApp()


@app.function_name(name="BTPDataConnector")
@app.schedule(
    schedule=f"0 */{TIMER_SCHEDULE_MINS} * * * *",
    arg_name="BTPDataConnector",
    run_on_startup=False,
    use_monitor=True,
)
# pylint: disable=invalid-name
def main(BTPDataConnector: func.TimerRequest) -> None:
    """Main function for the Azure Function App"""

    function_start_time_utc = datetime.utcnow().replace(microsecond=0)
    max_lookback_duration = function_start_time_utc - timedelta(
        hours=MAX_LOOKBACK_DURATION_HOURS
    )
    query_window_end = (
        function_start_time_utc - timedelta(minutes=QUERY_WINDOW_OFFSET_MINS)
    ).isoformat()

    if BTPDataConnector.past_due:
        logging.info("The timer is past due!")

    last_update_blob_container = ContainerClient.from_connection_string(
        conn_str=AZURE_WEB_JOBS_STORAGE, container_name=LAST_UPDATE_CONTAINER
    )

    if not last_update_blob_container.exists():
        logging.info("Creating blob storage container for last update timestamp")
        last_update_blob_container.create_container(public_access=None)

    try:
        logging.info("Downloading last update timestamp file")
        last_update_blob = json.loads(
            last_update_blob_container.download_blob(LAST_UPDATE_FILENAME).readall()
        )
        query_window_start = last_update_blob["lastUpdate"]

        if datetime.fromisoformat(query_window_start) < max_lookback_duration:
            logging.warning(
                "Last update date exceeds limit of %s hours. Older events will not be collected",
                MAX_LOOKBACK_DURATION_HOURS,
            )
            query_window_start = max_lookback_duration.isoformat()

    except ResourceNotFoundError:
        logging.info(
            "No last update timestamp file found in blob storage. Using %s hour query window.",
            MAX_LOOKBACK_DURATION_HOURS,
        )
        query_window_start = max_lookback_duration.isoformat()

    def check_http_response(response: httpx.Response) -> httpx.Response:
        try:
            response.raise_for_status()
        except httpx.TimeoutException as exc:
            logging.error("Request timed out: %s", exc)
            raise
        except httpx.HTTPStatusError as exc:
            logging.error(
                "HTTP error: %s, %s", exc.response.status_code, exc.response.text
            )
            raise
        return response

    def get_data(client: httpx.Client, url: str) -> list:
        response = client.get(
            url=url,
        )
        return check_http_response(response)

    logging.info("Requesting token from BTP")
    token_response = httpx.post(
        url=f"{BTP_UAA_URL}/oauth/token?grant_type=client_credentials",
        auth=(BTP_CLIENT_ID, BTP_CLIENT_KEY),
        headers={
            "accept": "application/x-www-form-urlencoded",
        },
    )
    btp_token = (check_http_response(token_response)).json().get("access_token")
    if not btp_token:
        raise KeyError("No access token returned from BTP")

    logs_ingestion_credential = ManagedIdentityCredential()
    logs_ingestion_client = LogsIngestionClient(
        endpoint=DCR_DCE_URL, credential=logs_ingestion_credential, logging_enable=True
    )

    last_data_timestamp = None

    with httpx.Client(base_url=BTP_API_HOST, timeout=BTP_API_TIMEOUT_SECONDS) as client:

        client.headers = {
            "accept": "application/json",
            "Authorization": f"Bearer {btp_token}",
        }

        api_path = "/auditlog/v2/auditlogrecords"
        query_string = f"?time_from={query_window_start}&time_to={query_window_end}"
        request_url = f"{api_path}{query_string}"
        next_page_header = True

        while next_page_header:

            logging.info("GET %s", request_url)
            response = get_data(url=request_url, client=client)
            if response.status_code == 200:
                if last_data_timestamp is None:
                    last_record_collected_timestamp = response.json()[0].get("time")
                    if last_record_collected_timestamp:
                        last_data_timestamp = (
                            datetime.fromisoformat(
                                last_record_collected_timestamp.replace("Z", "")
                            )
                            + timedelta(milliseconds=1)
                        ).isoformat()
                    else:
                        logging.error("No timestamp found in collected data")
                        break
            elif response.status_code == 204:
                logging.info("No logs to collect")
                break

            data = response.json()
            next_page_header = response.headers.get("paging", False)

            if next_page_header:
                request_url = f"{api_path}?{next_page_header}"

            if datetime.utcnow() > function_start_time_utc + timedelta(
                minutes=FUNCTION_SHUTDOWN_TIMEOUT_MINS
            ):
                logging.error("Stopping data collection due to time limit")
                next_page_header = False

            try:
                logging.info("Uploading %s logs to Ingestion API", len(data))
                # pylint: disable=no-value-for-parameter
                logs_ingestion_client.upload(
                    rule_id=DCR_IMMUTABLE_ID, stream_name=DCR_STREAM_NAME, logs=data
                )
            except HttpResponseError as exc:
                logging.error("Error sending data to Logs Ingestion API: %s", exc)
                raise

    if last_data_timestamp:
        logging.info(
            "Uploading last update timestamp JSON to blob storage %s",
            last_data_timestamp,
        )
        last_updated_data = {"lastUpdate": last_data_timestamp}
        last_update_blob_container.upload_blob(
            data=json.dumps(last_updated_data),
            name=LAST_UPDATE_FILENAME,
            overwrite=True,
        )
